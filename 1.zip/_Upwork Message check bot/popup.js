import { staticData } from './data.js';

document.addEventListener('DOMContentLoaded', () => {
  // Set the static data to the input fields
  document.getElementById('name').value = staticData.name;
  document.getElementById('email').value = staticData.email;
});