export const staticData = {
  name: "Upwork Message",
  email: "test@gmai.com",
  time: 0.167,
};
