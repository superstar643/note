import { staticData } from './data.js';

chrome.runtime.onInstalled.addListener(() => {
  chrome.alarms.create('checkMessages', { periodInMinutes: staticData.time }); // approximately every 5 seconds
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'checkMessages') {
    chrome.tabs.query({ url: "https://www.upwork.com/*" }, (tabs) => {
      if (tabs.length > 0) {
        chrome.scripting.executeScript({
          target: { tabId: tabs[0].id },
          func: checkForUnreadMessages
        }).catch(err => console.error('Failed to execute script:', err));
      }
    });
  }
});

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'notify') {
    chrome.notifications.create({
      type: 'basic',
      iconUrl: 'icons/icon48.png',
      title: 'Unread Messages Detected',
      message: `Name: ${staticData.name}\nEmail: ${staticData.email}`
    });
  } else if (request.type === 'saveInfo') {
    sendResponse({ success: false });
  }
});

function checkForUnreadMessages() {
  try {
    const unreadMessageBadge = document.querySelector("[data-cy='menu-item-trigger'] .nav-bubble");
    if (unreadMessageBadge) {
      chrome.runtime.sendMessage({ type: 'notify' });
    }
  } catch (error) {
    console.error(`Error: ${error.message}`);
  }
}